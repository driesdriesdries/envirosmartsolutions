<!-- The Modal -->
<div id="myModal" class="modal">
	<!-- Modal content -->
	<div class="modal-content">
		<span class="close">&times;</span>
		
		<h3>Contact Us</h3>
		<p>We appreciate your interest! Please fill out the form below and we will get back to you as soon as possible.</p>
		<?php echo do_shortcode( '[contact-form-7 id="470ed24" title="Contact form 1"]' ); ?>
	</div>
</div>
<!-- Modal Ends -->