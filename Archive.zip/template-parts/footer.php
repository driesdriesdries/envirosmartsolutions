<footer class="container footer">
    <div class="section section__footer">
        <a href="<?php echo site_url();?>"><img src="<?php echo get_theme_file_uri('images/logo.svg'); ?>" alt="EnviroSmart Logo"></a>
        <p>Copyright Notice: All content © <?php echo date("Y"); ?> EnviroSmart Solutions unless otherwise stated. </br> All rights reserved</p>   
    </div>
</footer>